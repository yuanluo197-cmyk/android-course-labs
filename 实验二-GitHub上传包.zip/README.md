# Android 课程实验与作业

| 实验 | 项目 | 内容 |
| --- | --- | --- |
| 实验二 | [Lab02ProgramAdviser](Lab02ProgramAdviser) | 动态添加 TextView、ScrollView、MVC 程序语言推荐 |

使用 Android Studio 打开 `Lab02ProgramAdviser` 文件夹即可构建运行。实验说明见项目内的 `实验说明.md`。
