package com.example.lab02

import android.app.Activity
import android.graphics.Typeface
import android.os.Build
import android.os.Bundle
import android.view.View
import android.view.ViewGroup
import android.view.WindowInsets
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.TextView

/** Controller：接收点击、调用 Model，并把结果显示到 View。 */
class MainActivity : Activity() {
    private val model = ProgramAdviserModel()
    private lateinit var itemsContainer: LinearLayout
    private lateinit var itemsScroll: ScrollView
    private lateinit var emptyText: TextView
    private lateinit var topicSpinner: Spinner
    private lateinit var resultText: TextView
    private var itemCount = 0
    private var hasResult = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val root = findViewById<View>(R.id.root)
        itemsContainer = findViewById(R.id.itemsContainer)
        itemsScroll = findViewById(R.id.itemsScroll)
        emptyText = findViewById(R.id.emptyText)
        topicSpinner = findViewById(R.id.topicSpinner)
        resultText = findViewById(R.id.resultText)

        // 状态栏和导航栏不会挡住页面内容。
        root.setOnApplyWindowInsetsListener { view, insets ->
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                val bars = insets.getInsets(WindowInsets.Type.systemBars())
                view.setPadding(bars.left, bars.top, bars.right, bars.bottom)
            } else {
                view.setPadding(
                    insets.systemWindowInsetLeft, insets.systemWindowInsetTop,
                    insets.systemWindowInsetRight, insets.systemWindowInsetBottom
                )
            }
            insets
        }
        root.requestApplyInsets()

        val adapter = ArrayAdapter.createFromResource(
            this, R.array.topics, android.R.layout.simple_spinner_item
        )
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        topicSpinner.adapter = adapter

        findViewById<Button>(R.id.addButton).setOnClickListener {
            addTextView(scrollToNewItem = true)
        }
        findViewById<Button>(R.id.queryButton).setOnClickListener {
            showRecommendation()
        }

        if (savedInstanceState != null) {
            repeat(savedInstanceState.getInt(KEY_ITEM_COUNT)) {
                addTextView(scrollToNewItem = false)
            }
            topicSpinner.setSelection(savedInstanceState.getInt(KEY_TOPIC))
            hasResult = savedInstanceState.getBoolean(KEY_HAS_RESULT)
            if (hasResult) showRecommendation()
        }
    }

    /** 区 1：每点击一次，新建一个 TextView 并加入滚动容器。 */
    private fun addTextView(scrollToNewItem: Boolean) {
        itemCount++
        emptyText.visibility = View.GONE
        val item = TextView(this).apply {
            text = getString(R.string.added_text, itemCount)
            textSize = 18f
            setTypeface(null, Typeface.BOLD)
            setTextColor(getColor(R.color.text_dark))
            val space = dp(12)
            setPadding(space, space, space, space)
        }
        itemsContainer.addView(
            item,
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        )
        if (scrollToNewItem) {
            itemsScroll.post { itemsScroll.fullScroll(ScrollView.FOCUS_DOWN) }
        }
    }

    /** 区 2：读取选择，查询模型，把资源字符串显示出来。 */
    private fun showRecommendation() {
        val topics = ProgramAdviserModel.Topic.entries
        val index = topicSpinner.selectedItemPosition.coerceIn(topics.indices)
        val advice = model.recommend(topics[index])
        val adviceString = when (advice) {
            ProgramAdviserModel.Advice.KOTLIN -> R.string.advice_kotlin
            ProgramAdviserModel.Advice.JAVASCRIPT -> R.string.advice_javascript
            ProgramAdviserModel.Advice.PYTHON -> R.string.advice_python
        }
        resultText.text = getString(R.string.result_format, getString(adviceString))
        hasResult = true
    }

    override fun onSaveInstanceState(outState: Bundle) {
        outState.putInt(KEY_ITEM_COUNT, itemCount)
        outState.putInt(KEY_TOPIC, topicSpinner.selectedItemPosition)
        outState.putBoolean(KEY_HAS_RESULT, hasResult)
        super.onSaveInstanceState(outState)
    }

    private fun dp(value: Int): Int =
        (value * resources.displayMetrics.density + 0.5f).toInt()

    private companion object {
        const val KEY_ITEM_COUNT = "item_count"
        const val KEY_TOPIC = "topic"
        const val KEY_HAS_RESULT = "has_result"
    }
}
