package com.example.lab02

/** 模型层：只处理用户选择和推荐规则，不操作界面控件。 */
class ProgramAdviserModel {
    enum class Topic { NEW_LANGUAGE, WEB_INTERACTION, DATA_ANALYSIS }
    enum class Advice { KOTLIN, JAVASCRIPT, PYTHON }

    fun recommend(topic: Topic): Advice = when (topic) {
        Topic.NEW_LANGUAGE -> Advice.KOTLIN
        Topic.WEB_INTERACTION -> Advice.JAVASCRIPT
        Topic.DATA_ANALYSIS -> Advice.PYTHON
    }
}
