package com.example.lab02

import org.junit.Assert.assertEquals
import org.junit.Test

class ProgramAdviserModelTest {
    private val model = ProgramAdviserModel()

    @Test
    fun recommendationMatchesEveryTopic() {
        assertEquals(ProgramAdviserModel.Advice.KOTLIN,
            model.recommend(ProgramAdviserModel.Topic.NEW_LANGUAGE))
        assertEquals(ProgramAdviserModel.Advice.JAVASCRIPT,
            model.recommend(ProgramAdviserModel.Topic.WEB_INTERACTION))
        assertEquals(ProgramAdviserModel.Advice.PYTHON,
            model.recommend(ProgramAdviserModel.Topic.DATA_ANALYSIS))
    }
}
